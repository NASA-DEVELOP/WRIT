# Import system modules
import arcpy

# Set workspace
arcpy.env.workspace = "C:\\Miami_Beach\\Data\\GEODB\\MDWR.gdb"

# Set local variables
inNetCDFFile = "C:\\Miami_Beach\\Data\\IMAGERY\\Landsat8\\LC08_L1TP_015042_20161022_20170219_01_T1\\LC08_L1TP_015042_20161022_20170219_01_T1_L2.nc"
variable = "RHOW_443"
XDimension = "x"
YDimension = "y"
outRasterLayer = "rainfall"
bandDimmension = ""
dimensionValues = ""
valueSelectionMethod = ""

out_layer_file = "C:\\Miami_Beach\\Data\\IMAGERY\\Landsat8\\LC08_L1TP_015042_20161022_20170219_01_T1\\TEST_Netcdf.tif"
# Execute MakeNetCDFRasterLayer
arcpy.MakeNetCDFRasterLayer_md(inNetCDFFile, variable, XDimension, YDimension,
                               outRasterLayer, bandDimmension, dimensionValues, 
                               valueSelectionMethod)

# Execute SaveToLayerFile
#arcpy.SaveToLayerFile_management(outRasterLayer, out_layer_file, "ABSOLUTE")
arcpy.CopyRaster_management(outRasterLayer,"outNetCDF","DEFAULTS","","","","","32_BIT_FLOAT")
