import arcpy
from arcpy.sa import *

arcpy.env.workspace = r"C:\Miami_Beach\Data\GEODB\MDWR.gdb"
arcpy.env.overwriteOutput = True
##Shift a TIFF image by 4.5 in X direction and 6 in Y direction
##Snap the output to a existing raster dataset

sRaster = Raster("LC08_L1TP_015042_20161022_20170219_01_T1_B1")
tRaster = Raster("rtoa_483_Layer1")
oRaster = Raster("rtoa_483_Layer2")
#arcpy.env.extent = arcpy.Extent(-107.0, 38.0, -104.0, 40.0)
cellSize = 30

desc = arcpy.Describe(sRaster)
sr = desc.spatialReference.factoryCode

arcpy.DefineProjection_management(tRaster, sr)
arcpy.env.snapRaster =sRaster 
sExtent = sRaster.extent
print("XMin: {0}, YMin: {1}".format(sExtent.XMin, sExtent.YMin))
print("XMax: {0}, YMax: {1}".format(sExtent.XMax, sExtent.YMax))



tExtent = tRaster.extent
print("XMin: {0}, YMin: {1}".format(tExtent.XMin, tExtent.YMin))
print("XMax: {0}, YMax: {1}".format(tExtent.XMax, tExtent.YMax))
# Check out the ArcGIS Spatial Analyst extension license
arcpy.CheckOutExtension("Spatial")


#arcpy.Shift_management("image.tif", "shift.tif", "4.5", "6", "snap.tif")


##Warp a TIFF raster dataset with control points
##Define source control points
#source_pnt = "'234718 3804287';'241037 3804297';'244193 3801275'"
source_pnt = '"' + ("'" + "{0} {1}".format(sExtent.XMin, sExtent.YMin)+ "'") + ";" + ("'" + "{0} {1}".format(sExtent.XMax, sExtent.YMax) + "'") + ";" + \
             ("'" + "{0} {1}".format(sExtent.XMin, sExtent.YMax) + "'") + ";" + ("'" + "{0} {1}".format(sExtent.XMax, sExtent.YMin) + "'") + '"'
print source_pnt

##Define target control points
#WHAT!!! _____  ___ __ _ _ _ _
#target_pnt = outpnts = '"' + ("'" + "{0} {1}".format(tExtent.XMin, tExtent.YMin)+ "'") + ";" + ("'" + "{0} {1}".format(tExtent.XMax, tExtent.YMax) + "'") + \
             ";" + ("'" + "{0} {1}".format(tExtent.XMin, tExtent.YMax) + "'") + ";" + ("'" + "{0} {1}".format(sExtent.XMax, sExtent.YMin) + "'") + '"'

# Do this tomorrow
columns = (XMax - xmin) / cell size
rows = (ymax - ymin) / cell size

#arcpy.Shift_management(sRaster, oRaster, "100",\
                      # "150", sRaster)
print target_pnt
#arcpy.Warp_management(tRaster, source_pnt, target_pnt, "warp", "POLYORDER3",\
#                      "NEAREST")
print "Check your warp"
