import csv
import os, sys
from Tkinter import *
import sys

# Open a file
###path = "/var/www/html/"

Path = "C:\Miami_Beach\Data\IMAGERY\Landsat8\LC08_L1TP_015042_20161022_20170219_01_T1"
dirs = os.listdir(Path)

# List the extension you want to extract
#param0 =
#param1 =

# This would print all the files and directories

with open(r'C:\Miami_Beach\Data\IMAGERY\Landsat8\LC08_L1TP_015042_20161022_20170219_01_T1\ImageList.txt', 'w') as txtFile:
    #wr = csv.writer(myfile, quoting=' '.QUOTE_ALL)
    #wr.writerow(file)
    for file in dirs:
    #fileList = []
        #alert = driver.switch_to_alert()
        #alert_text = alert.text
        #var_text = driver.execute_script("""var someVariable = "someValue"; return someVariable;""")
#print(var_text) # Output- "someValue"
        if '.TIF' in file:
            #fileList.append(file)
            txtFile.write(Path + file)
            txtFile.write("\n")

##        if not '.TIF' in file:
##            class popupWindow(object):
##                def __init__(self,master):
##                    top=self.top=Toplevel(master)
##                    self.l=Label(top,text="ALERT! YOU HAVE FILES THAT ARE NOT ___")
##                    self.l.pack()
##                    self.e=Entry(top)
##                    self.e.pack()
##                    self.b=Button(top,text='Ok',command=self.cleanup)
##                    self.b.pack()
##                def cleanup(self):
##                    self.value=self.e.get()
##                    self.top.destroy()
                   
              
txtFile.close()
        
