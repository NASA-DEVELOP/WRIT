import csv
import os, sys
import commands
from subprocess import Popen, PIPE, STDOUT

# Open a file
###path = "/var/www/html/"

Path = "C:\Miami_Beach\Data\IMAGERY\Landsat8\LC08_L1TP_015042_20161022_20170219_01_T1"
dirs = os.listdir(Path)

# List the extension you want to extract
#param0 =
#param1 =

# This would print all the files and directories

with open(r'C:\Miami_Beach\Data\IMAGERY\Landsat8\LC08_L1TP_015042_20161022_20170219_01_T1\ImageList.txt', 'w') as txtFile:
for path, subdirs, files in os.walk(r"W:\Commons\Jeanie_Zac_Amanda\Final_Project\test\buffer_shapefiles"): 
    for x in files:
        if x.endswith(".TIF"):
            
        #if '.TIF' in file:
            #fileList.append(file)
            txtFile.write(Path + file)
            txtFile.write("\n")
                 
              
txtFile.close()
        
##pipe = os.popen("cmd", 'w')
##>>> import shlex, subprocess
##>>> command_line = raw_input()
##/bin/vikings -input eggs.txt -output "spam spam.txt" -cmd "echo '$MONEY'"
##>>> args = shlex.split(command_line)
##>>> print args
##['/bin/vikings', '-input', 'eggs.txt', '-output', 'spam spam.txt', '-cmd', "echo '$MONEY'"]
##>>> p = subprocess.Popen(args) # Success!


shell_command = "cd 'Program Files (x86)'" #\acolite_win\idl84\bin\bin.x86_64\idlrt.exe'
event = Popen(shell_command, shell=True, stdin=PIPE, stdout=PIPE, 
    stderr=STDOUT)
output = event.communicate()
print "that worked"

#rc = pipe.close()
