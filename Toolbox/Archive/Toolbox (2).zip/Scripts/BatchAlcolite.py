import arcpy
import commands
import shlex, subprocess
import os, os.path
import sys


import subprocess
 
cfgFile = "C:\\Miami_Beach\\Toolbox\\acolite_settings_NIR.cfg"
imageTXT = "C:\\Miami_Beach\\Scripts\\ImageList2.txt"
acoliteSav = "C:\\Program Files (x86)\\acolite_win\\acolite.sav"
acolitePath = "C:\\Program Files (x86)\\acolite_win\\idl84\\bin\\bin.x86_64\\idlrt.exe"






# THIS COMMAND OPENS THE PROGRAM #
#subprocess.Popen([acolitePath, acoliteSav])

args = [acolitePath, acoliteSav] + cfgFile, imageTXT
# THIS COMMAND OPENS THE PROGRAM #

subprocess.Popen(args)

####arcpam = [cdgFile, imageTXT]
#proc = subprocess.Popen(constant_cmd_part,
                        #stdout=subprocess.PIPE)

####myDict = {cdgFile, imageTXT}


####print sys.argv[1]


# # # # # # # # # # # subprocess.Popen([acolitePath, acoliteSav],[cdgFile] + [imageTXT], ) 

###

###feature_class = "c:/Data/Florida.gdb/airports"
##
### Fetch each feature from the cursor and examine the extent properties
##for row in arcpy.da.SearchCursor(feature_class, ["SHAPE@", "CNTY_NAME"]):
##    extent = row[0].extent
##    print("Extent of county {0}:".format(row[1]))
##    print("XMin: {0}, YMin: {1}".format(extent.XMin, extent.YMin))
##    print("XMax: {0}, YMax: {1}".format(extent.XMax, extent.YMax))

#pipe = os.popen("cmd", 'w')
#Popen(['/bin/sh', '-c', args[0], args[1], ...])
#command_line = raw_input()

#args = shlex.split(command_line)
#print args
