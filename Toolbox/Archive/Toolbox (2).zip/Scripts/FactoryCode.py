import arcpy

# Describe a feature class
#
fc = r"C:\Miami_Beach\Data\GEODB\MDWR.gdb\Bathymetry"
desc = arcpy.Describe(fc)

# Get the spatial reference 
#
sr = desc.spatialReference.factoryCode
print sr

# Check if the feature class is in projected space
#
#if sr.type == "Projected":
    #arcpy.Copy_management(fc,"D:/St_Johns/data.gdb/roads_UTM")
